#include "Polinom.h"

Polinom::Polinom()
{
}

Polinom::~Polinom()
{
}

void Polinom::  polinomOlustur() 
{
	cout<<"Polinom olusturma... "<< endl; 
	cout<<"P(X) = ax� + bx + c  "<< endl; 
	cout<<"Polinomunun a,b,c  degerlerini giriniz "<< endl;
	cout<<"a: "; cin>>a; 
	cout<<"b: "; cin>>b; 
	cout<<"c: "; cin>>c;
	system("cls") ; 
	cout<<"olusturdugunuz polinom ..."<< endl<< endl ; 
	
	cout<<"P(X) = "<<a<<"x� + "<<b<< "x + "<< c << endl; 
	
	
	cout<<"x degerini giriniz :";
	cout<<"x :" ; cin>>x; 

	cout<<"P("<<x<<") = "<<a<<"x� + "<<b<< "x + "<< c << endl; 
	
}
void  Polinom:: hesapla()
{
	sonuc= a*x*x + b*x + c ; 	
	cout<<"P("<<x<<") = "<<a<<"x� + "<<b<< "x + "<< c  << " = " << sonuc<<  endl; 
	
	
} 
void Polinom::  kokleriBul()
{
	delta = b*b - 4*a*c; 
	if( delta < 0  ) 
	cout<<"Real kok yok !"<<endl; 
	else if( delta == 0 ) 
	{
		cout<<"Cakisik kok var "<< endl; 
		kok1=  ( -b ) / ( 2*a ) ; 
		cout<<"kok = " << kok1<< endl; 
	}
	else 
	{
		cout<<"Farkli iki k�k var "<< endl; 
		kok1=  ( -b - sqrt(delta) ) / ( 2*a ) ;
		kok2=  ( -b + sqrt(delta) ) / ( 2*a ) ;
		 
		cout<<"kok1 = " << kok1<< endl;
		cout<<"kok2 = " << kok2<< endl;
	}
	
}
void  Polinom:: kokDegistir()
{
	cout<<"yeni x degerini giriniz :";
	cout<<"x :" ; cin>>x; 

	cout<<"P("<<x<<") = "<<a<<"x� + "<<b<< "x + "<< c << endl; 
	
	
}
int  Polinom:: menu() 
{
	int secim; 
	cout<<"\nPOLINOM UYGULAMASI "<< endl<< endl; 
	cout<<"1- polinom olustur "<< endl; 
	cout<<"2- hesapla  "<< endl; 
	cout<<"3- kokleri bul  "<< endl; 
	cout<<"4- kok degistir  "<< endl; 
	cout<<"0- programi kapat  "<< endl;
	cout<<"seciminiz :  " ;cin >> secim; 
	system("cls") ; 
	
	return secim; 
	
}
void  Polinom:: giris()
{
	int secim= menu(); 
	while( secim != 0  ) 
	{
		switch(secim ) 
		{
			case 1: polinomOlustur() ; break; 
			case 2: hesapla() ; break; 
			case 3: kokleriBul() ; break; 
			case 4: kokDegistir() ; break; 
			case 0: break; 
			default : cout<<"Hatali islem ! "<< endl; break; 
		}
		secim= menu(); 
	}
	
} 


