#include <iostream>
#include "Polinom.h"  // s�n�f� k�t�phanesini dahil ettik 

using namespace std; 
// Bilgisayar M�hendisi Sad�k �AH�N 


int main(  ) {
	setlocale(LC_ALL, "") ; 
	
	
	 Polinom nesne; 
	 nesne.giris() ; 
	 
	
	
	return 0;
}
